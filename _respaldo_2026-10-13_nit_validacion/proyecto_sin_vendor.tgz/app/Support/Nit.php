<?php

namespace App\Support;

use Closure;

/**
 * NIT de persona jurídica en Colombia: 9 dígitos + 1 dígito de verificación (DV).
 *
 *   En pantalla:          800.000.000-9
 *   En la base de datos:  8000000009   (BIGINT, sin puntos ni guion)
 *
 * El DV se calcula con el algoritmo módulo 11 de la DIAN: cada dígito del NIT,
 * de derecha a izquierda, se multiplica por 3, 7, 13, 17, 19, 23, 29, 37, 41...
 * se suma todo y se saca el residuo entre 11. Si el residuo es 0 o 1 ese es el DV;
 * si no, el DV es 11 - residuo.
 */
class Nit
{
    private const PESOS = [3, 7, 13, 17, 19, 23, 29, 37, 41, 43, 47, 53, 59, 67, 71];

    /** Deja solo los dígitos: "800.000.000-9" → "8000000009". */
    public static function normalizar(?string $nit): string
    {
        return preg_replace('/\D/', '', (string) $nit);
    }

    /** Dígito de verificación de los 9 dígitos base. */
    public static function digitoVerificacion(string $base): int
    {
        $base = self::normalizar($base);
        $suma = 0;
        $digitos = strrev($base);

        for ($i = 0; $i < strlen($digitos); $i++) {
            $suma += (int) $digitos[$i] * self::PESOS[$i];
        }

        $residuo = $suma % 11;

        return $residuo > 1 ? 11 - $residuo : $residuo;
    }

    /** ¿Son 10 dígitos y el último es el DV correcto de los 9 primeros? */
    public static function esValido(?string $nit): bool
    {
        $nit = self::normalizar($nit);

        return (bool) preg_match('/^\d{10}$/', $nit)
            && self::digitoVerificacion(substr($nit, 0, 9)) === (int) substr($nit, -1);
    }

    /** 8000000009 → "800.000.000-9" (si no tiene 10 dígitos lo devuelve tal cual). */
    public static function formatear(int|string|null $nit): string
    {
        $nit = self::normalizar((string) $nit);

        if (strlen($nit) !== 10) {
            return $nit;
        }

        return number_format((int) substr($nit, 0, 9), 0, ',', '.') . '-' . substr($nit, -1);
    }

    /**
     * Reglas de Laravel para el NIT ya normalizado.
     * $conDv = false solo revisa que sean 10 dígitos (para buscar ópticas ya registradas).
     */
    public static function reglas(bool $conDv = true): array
    {
        $reglas = ['required', 'digits:10'];

        if ($conDv) {
            $reglas[] = function (string $atributo, mixed $valor, Closure $fallar) {
                if (! self::esValido((string) $valor)) {
                    $fallar('El dígito de verificación del NIT no es correcto. Revisa el número.');
                }
            };
        }

        return $reglas;
    }

    public static function mensajes(string $campo = 'nit'): array
    {
        return [
            "{$campo}.required" => 'Escribe el NIT.',
            "{$campo}.digits" => 'El NIT debe tener 9 dígitos más el dígito de verificación (ej. 800.000.000-9).',
        ];
    }
}
