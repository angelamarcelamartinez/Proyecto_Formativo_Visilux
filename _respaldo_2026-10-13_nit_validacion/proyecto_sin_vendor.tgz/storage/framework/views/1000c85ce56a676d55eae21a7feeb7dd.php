<?php $pageTitle = 'Planes'; ?>
<?php echo $__env->make('includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- ======================================================
     BANNER DE LA PÁGINA
====================================================== -->
<section class="page-header">
    <div class="container text-center">
        <span class="page-eyebrow d-block mb-2">Planes y precios</span>
        <h1 class="page-title display-5 mb-3">Nuestros Planes</h1>
        <p class="page-subtitle mx-auto">
            Elige el plan que mejor se adapte al tamaño de tu óptica y accede
            a las funciones que necesitas, cuando las necesites.
        </p>
    </div>
</section>

<?php echo $__env->make('partials.planes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\visilux_3\resources\views/planes.blade.php ENDPATH**/ ?>