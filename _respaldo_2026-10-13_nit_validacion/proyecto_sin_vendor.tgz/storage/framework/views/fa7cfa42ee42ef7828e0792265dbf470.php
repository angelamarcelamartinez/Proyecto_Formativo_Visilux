<?php echo $__env->make('includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- ======================================================
     BANNER DE LA PÁGINA
====================================================== -->
<section class="page-header">
    <div class="container text-center">
        <span class="page-eyebrow d-block mb-2">Reserva en línea</span>
        <h1 class="page-title display-5 mb-3">Agenda tu Cita</h1>
        <p class="page-subtitle mx-auto">
            Escoge el día y la hora que mejor te queden entre los horarios disponibles
            de nuestros optómetras.
        </p>
    </div>
</section>

<!-- ======================================================
     FORMULARIO DE AGENDAMIENTO
====================================================== -->
<section class="py-5">
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">

                <?php if(session('cita_reservada')): ?>
                    <?php $c = session('cita_reservada'); ?>
                    <div class="alert alert-success border-0 shadow-sm p-4 mb-4">
                        <h5 class="fw-semibold mb-2"><i class="bi bi-check-circle me-2"></i>¡Tu cita quedó reservada!</h5>
                        <p class="mb-0">
                            <?php echo e($c['tipo']); ?> el <strong><?php echo e($c['fecha']); ?></strong> a las <strong><?php echo e($c['hora']); ?></strong>
                            con <?php echo e($c['optometra']); ?>. Te esperamos 10 minutos antes.
                        </p>
                    </div>
                <?php endif; ?>

                <?php if(session('cita_enviada')): ?>
                    <?php $c = session('cita_enviada'); ?>
                    <div class="alert alert-success border-0 shadow-sm p-4 mb-4">
                        <h5 class="fw-semibold mb-2"><i class="bi bi-envelope-check me-2"></i>¡Recibimos tu solicitud!</h5>
                        <p class="mb-0">
                            Pediste <?php echo e(mb_strtolower($c['tipo'])); ?> el <strong><?php echo e($c['fecha']); ?></strong> a las
                            <strong><?php echo e($c['hora']); ?></strong> con <?php echo e($c['optometra']); ?>. Te contactaremos para confirmarla.
                        </p>
                    </div>
                <?php endif; ?>

                <?php if($usuario && $proximasCitas->isNotEmpty()): ?>
                    <div class="card border-0 shadow-sm p-4 mb-4">
                        <h5 class="fw-semibold mb-3"><i class="bi bi-calendar2-week me-2"></i>Tus próximas citas</h5>
                        <ul class="list-unstyled mb-0">
                            <?php $__currentLoopData = $proximasCitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="d-flex flex-wrap justify-content-between gap-2 py-2 border-bottom">
                                    <span>
                                        <strong><?php echo e(\Illuminate\Support\Carbon::parse($pc->fecha_cita)->locale('es')->translatedFormat('D j M Y')); ?></strong>
                                        · <?php echo e(substr($pc->hora_cita, 0, 5)); ?> · <?php echo e($pc->nombre_tipo); ?> con <?php echo e($pc->optometra); ?>

                                    </span>
                                    <span class="badge rounded-pill text-bg-light border"><?php echo e($pc->nom_estado); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                    <div class="alert alert-light border shadow-sm d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
                        <span>
                            <i class="bi bi-info-circle me-1"></i>
                            <strong>¿Ya tienes cuenta?</strong> Inicia sesión y tu cita queda reservada al instante.
                            Si no, envía tu solicitud y te confirmamos por teléfono o correo.
                        </span>
                        <span class="d-flex gap-2">
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-gradient rounded-pill px-3">Iniciar sesión</a>
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3">Registrarme</a>
                        </span>
                    </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm p-4 p-md-5">
                    <form method="POST" action="<?php echo e(route('citas.store')); ?>" id="form-cita" novalidate>
                        <?php echo csrf_field(); ?>

                        
                        <h5 class="fw-semibold mb-3"><span class="badge rounded-pill bg-dark me-2">1</span>Tus datos</h5>

                        <?php if(auth()->guard()->check()): ?>
                            <div class="bg-light rounded-3 p-3 mb-4 small">
                                <div><strong><?php echo e($usuario->nombres); ?> <?php echo e($usuario->apellido); ?></strong></div>
                                <div class="text-muted">Documento <?php echo e($usuario->documento); ?> · <?php echo e($usuario->email); ?> · <?php echo e($usuario->telefono); ?></div>
                            </div>
                        <?php else: ?>
                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <label for="nombre" class="form-label fw-medium">Nombre completo</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>" required>
                                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label for="id_tipo_docu" class="form-label fw-medium">Tipo de documento</label>
                                    <select class="form-select <?php $__errorArgs = ['id_tipo_docu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_tipo_docu" name="id_tipo_docu" required>
                                        <option value="" disabled <?php echo e(old('id_tipo_docu') ? '' : 'selected'); ?>>Selecciona</option>
                                        <?php $__currentLoopData = $tiposDocumento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($td->id_tipo_docu); ?>" <?php if((string) old('id_tipo_docu') === (string) $td->id_tipo_docu): echo 'selected'; endif; ?>><?php echo e($td->nom_ti_docu); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['id_tipo_docu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label for="documento" class="form-label fw-medium">Número de documento</label>
                                    <input type="text" inputmode="numeric" class="form-control <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="documento" name="documento" value="<?php echo e(old('documento')); ?>" required>
                                    <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label for="telefono" class="form-label fw-medium">Teléfono</label>
                                    <input type="tel" class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="telefono" name="telefono" value="<?php echo e(old('telefono')); ?>" required>
                                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12">
                                    <label for="correo" class="form-label fw-medium">Correo electrónico</label>
                                    <input type="email" class="form-control <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="correo" name="correo" value="<?php echo e(old('correo')); ?>" required>
                                    <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        
                        <h5 class="fw-semibold mb-3"><span class="badge rounded-pill bg-dark me-2">2</span>¿Qué necesitas?</h5>
                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <label for="id_tipo_cita" class="form-label fw-medium">Tipo de cita</label>
                                <select class="form-select <?php $__errorArgs = ['id_tipo_cita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_tipo_cita" name="id_tipo_cita" required>
                                    <option value="" disabled <?php echo e(old('id_tipo_cita') ? '' : 'selected'); ?>>Selecciona</option>
                                    <?php $__currentLoopData = $tiposCita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tc->id_tipo_cita); ?>" <?php if((string) old('id_tipo_cita') === (string) $tc->id_tipo_cita): echo 'selected'; endif; ?>><?php echo e($tc->nombre_tipo); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['id_tipo_cita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label for="id_motivo" class="form-label fw-medium">Motivo de la cita</label>
                                <select class="form-select <?php $__errorArgs = ['id_motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_motivo" name="id_motivo" required>
                                    <option value="" disabled <?php echo e(old('id_motivo') ? '' : 'selected'); ?>>Selecciona un motivo</option>
                                    <?php $__currentLoopData = $motivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($motivo->id_motivo); ?>" <?php if((string) old('id_motivo') === (string) $motivo->id_motivo): echo 'selected'; endif; ?>><?php echo e($motivo->nombre_motivo); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['id_motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <h5 class="fw-semibold mb-3"><span class="badge rounded-pill bg-dark me-2">3</span>Día y hora</h5>
                        <div class="row g-3 mb-2">
                            <div class="col-md-6">
                                <label for="fecha" class="form-label fw-medium">Fecha</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="fecha" name="fecha" value="<?php echo e(old('fecha')); ?>"
                                       min="<?php echo e($fechaMin); ?>" max="<?php echo e($fechaMax); ?>" required>
                                <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 d-flex align-items-end">
                                <p class="small text-muted mb-2">
                                    <?php if(count($diasAtencion)): ?>
                                        Atendemos citas los días: <strong><?php echo e(implode(', ', $diasAtencion)); ?></strong>.
                                    <?php else: ?>
                                        En este momento no hay horarios de atención publicados.
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>

                        <input type="hidden" name="hora" id="hora" value="<?php echo e(old('hora')); ?>">
                        <input type="hidden" name="id_optometra" id="id_optometra" value="<?php echo e(old('id_optometra')); ?>">

                        <div id="turnos" class="mb-2" data-url="<?php echo e(route('citas.horarios')); ?>">
                            <p class="text-muted small mb-0">Escoge una fecha para ver los horarios disponibles.</p>
                        </div>
                        <?php $__errorArgs = ['hora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block mb-2"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['id_optometra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php if(! $errors->has('hora')): ?> <span class="invalid-feedback d-block mb-2"><?php echo e($message); ?></span> <?php endif; ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="mt-4">
                            <label for="comentario" class="form-label fw-medium">Comentario adicional (opcional)</label>
                            <textarea class="form-control <?php $__errorArgs = ['comentario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="comentario" name="comentario" rows="3" maxlength="500"><?php echo e(old('comentario')); ?></textarea>
                            <?php $__errorArgs = ['comentario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" id="btn-cita" class="btn btn-gradient rounded-pill px-4 mt-4" disabled>
                            <i class="bi bi-calendar-check me-2"></i>
                            <?php if(auth()->guard()->check()): ?> Reservar cita <?php else: ?> Enviar solicitud <?php endif; ?>
                        </button>
                        <p class="small text-muted mt-2 mb-0" id="ayuda-boton">Escoge un horario para continuar.</p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    .turno-btn { min-width: 150px; text-align: left; }
    .turno-btn.active { background: var(--gold); border-color: var(--gold); color: #fff; }
</style>

<script>
(function () {
    const fecha = document.getElementById('fecha');
    const cont = document.getElementById('turnos');
    const hora = document.getElementById('hora');
    const opt = document.getElementById('id_optometra');
    const btn = document.getElementById('btn-cita');
    const ayuda = document.getElementById('ayuda-boton');

    function seleccionar(h, o) {
        hora.value = h || '';
        opt.value = o || '';
        const listo = !!(h && o);
        btn.disabled = !listo;
        ayuda.textContent = listo ? '' : 'Escoge un horario para continuar.';
        cont.querySelectorAll('.turno-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.hora === h && b.dataset.opt === String(o));
        });
    }

    function cargar(conservar) {
        if (!fecha.value) return;
        if (!conservar) seleccionar('', '');
        cont.innerHTML = '<p class="text-muted small mb-0"><span class="spinner-border spinner-border-sm me-2"></span>Buscando horarios...</p>';

        fetch(cont.dataset.url + '?fecha=' + encodeURIComponent(fecha.value), { headers: { 'Accept': 'application/json' } })
            .then(r => r.json())
            .then(data => {
                const turnos = data.turnos || [];
                if (!turnos.length) {
                    cont.innerHTML = '<div class="alert alert-warning small mb-0">No hay horarios disponibles el ' +
                        (data.dia || 'día') + ' seleccionado. Prueba con otra fecha.</div>';
                    seleccionar('', '');
                    return;
                }
                cont.innerHTML = '<p class="small fw-medium mb-2">Horarios disponibles (' + data.dia + '):</p>' +
                    '<div class="d-flex flex-wrap gap-2">' + turnos.map(t =>
                        '<button type="button" class="btn btn-outline-secondary btn-sm rounded-3 turno-btn" data-hora="' + t.hora +
                        '" data-opt="' + t.id_optometra + '"><strong>' + t.hora + '</strong><br><small>' +
                        t.optometra.replace(/</g, '&lt;') + '</small></button>').join('') + '</div>';
                if (conservar) seleccionar(hora.value, opt.value);
            })
            .catch(() => {
                cont.innerHTML = '<div class="alert alert-danger small mb-0">No se pudieron cargar los horarios. Intenta de nuevo.</div>';
            });
    }

    cont.addEventListener('click', e => {
        const b = e.target.closest('.turno-btn');
        if (b) seleccionar(b.dataset.hora, b.dataset.opt);
    });
    fecha.addEventListener('change', () => cargar(false));

    // Si el formulario volvió con errores, se recargan los horarios de la fecha escogida
    if (fecha.value) cargar(true);
})();
</script>

<?php echo $__env->make('includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\visilux_3\resources\views/agendar-cita.blade.php ENDPATH**/ ?>