
<?php
    $detail = $detail ?? false;
    $val = $row->{$col['name']} ?? null;
    $name = $col['name'];
    $isMoney = collect(['precio', 'total', 'subtotal', 'impuesto', 'descuento'])->contains(fn ($h) => str_contains($name, $h));
?>

<?php if(is_null($val) || $val === ''): ?>
    <span class="text-muted">—</span>
<?php elseif($col['type'] === 'file'): ?>
    <?php
        $src = \Illuminate\Support\Str::startsWith($val, ['http://', 'https://', '/'])
            ? $val
            : asset(($col['upload_dir'] ?? 'assets/img/productos').'/'.$val);
    ?>
    <img src="<?php echo e($src); ?>" alt="<?php echo e($col['label']); ?>"
         class="<?php echo e($detail ? 'rounded-xl border border-olive-100 max-h-56 object-contain' : 'w-10 h-10 rounded-lg object-cover border border-olive-100'); ?>"
         onerror="this.replaceWith(Object.assign(document.createElement('span'), {className: 'text-muted text-xs', textContent: 'Sin imagen'}))">
<?php elseif(!empty($col['is_fk']) && empty($col['list_raw'])): ?>
    <?php if(isset($fkMaps[$name][(string) $val])): ?>
        <span class="text-ink/90"><?php echo e($fkMaps[$name][(string) $val]); ?></span>
    <?php else: ?>
        
        <span class="text-red-600" title="Este valor no existe en <?php echo e($col['fk_table']); ?>"><?php echo e($val); ?> <small>(no registrado)</small></span>
    <?php endif; ?>
<?php elseif($col['type'] === 'decimal' && $isMoney): ?>
    <span class="font-medium">$<?php echo e(number_format((float) $val, 2)); ?></span>
<?php elseif($col['type'] === 'time'): ?>
    <?php echo e(substr($val, 0, 5)); ?>

<?php elseif($col['type'] === 'datetime-local'): ?>
    <?php echo e(substr($val, 0, 16)); ?>

<?php elseif($col['type'] === 'date'): ?>
    <?php echo e(substr($val, 0, 10)); ?>

<?php elseif($col['type'] === 'textarea' && ! $detail): ?>
    <span class="block truncate" title="<?php echo e($val); ?>"><?php echo e(\Illuminate\Support\Str::limit($val, 40)); ?></span>
<?php elseif(!empty($col['is_pk']) && ! $detail): ?>
    <span class="font-mono text-[12px] text-ink/70"><?php echo e($val); ?></span>
<?php else: ?>
    <span class="<?php echo e($detail ? 'whitespace-pre-line break-words' : ''); ?>"><?php echo e($val); ?></span>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\visilux_3\resources\views/admin/crud/_cell.blade.php ENDPATH**/ ?>