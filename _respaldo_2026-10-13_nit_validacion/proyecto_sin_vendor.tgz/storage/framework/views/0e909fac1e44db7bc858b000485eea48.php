
<div data-total="<?php echo e($rows->total()); ?>">
    <div class="bg-white rounded-2xl border border-olive-100 shadow-card overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full text-sm">
                <thead>
                    <tr class="bg-creamdark/60 text-left text-[11px] uppercase tracking-wider text-muted">
                        <?php $__currentLoopData = $listColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="px-4 py-3 font-semibold whitespace-nowrap"><?php echo e($col['label']); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-5 py-3 font-semibold text-right whitespace-nowrap">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-olive-100">
                    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $rowId = $row->{$config['primary_key']}; ?>
                        <tr class="hover:bg-creamdark/30 transition">
                            <?php $__currentLoopData = $listColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="px-4 py-3 align-top max-w-[16rem]">
                                    <?php echo $__env->make('admin.crud._cell', ['col' => $col, 'row' => $row, 'fkMaps' => $fkMaps, 'detail' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td class="px-5 py-3 text-right whitespace-nowrap">
                                <div class="inline-flex items-center gap-1">
                                    <?php if($hasMore): ?>
                                        <button type="button" data-detail="detail-<?php echo e($table); ?>-<?php echo e($loop->index); ?>"
                                                class="js-ver-mas inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-olive-700 bg-olive-50 hover:bg-olive-100"
                                                title="Ver toda la información">
                                            <?php echo $__env->make('partials.icon', ['name' => 'eye', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                            Ver más
                                        </button>
                                    <?php endif; ?>
                                    <?php if (! (\App\Support\Alcance::soloLectura($table))): ?>
                                    <a href="<?php echo e(route('admin.crud.edit', [$table, $rowId])); ?>"
                                       class="p-2 rounded-lg text-olive-600 hover:bg-olive-100" title="Editar">
                                        <?php echo $__env->make('partials.icon', ['name' => 'pencil', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </a>
                                    <?php if($table === 'usuario' && (string) $rowId !== (string) auth()->id() && (int) $row->id_rol !== 1): ?>
                                        
                                        <?php $inactivo = (int) $row->id_estado === \App\Support\BloqueoUsuarios::ESTADO_INACTIVO; ?>
                                        <form method="POST" action="<?php echo e(route('admin.usuario.estado', $rowId)); ?>"
                                              onsubmit="return confirm('<?php echo e($inactivo ? '¿Activar este usuario? Podrá volver a iniciar sesión.' : '¿Desactivar este usuario? No podrá iniciar sesión hasta que lo actives.'); ?>');">
                                            <?php echo csrf_field(); ?>
                                            <?php if($inactivo): ?>
                                                <button type="submit" title="Activar usuario"
                                                        class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-50">
                                                    <?php echo $__env->make('partials.icon', ['name' => 'user', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                    Activar
                                                </button>
                                            <?php else: ?>
                                                <button type="submit" title="Desactivar usuario"
                                                        class="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-red-600 bg-red-50 hover:bg-red-50">
                                                    <?php echo $__env->make('partials.icon', ['name' => 'lock', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                    Desactivar
                                                </button>
                                            <?php endif; ?>
                                        </form>
                                    <?php endif; ?>
                                    <?php if($table !== 'usuario'): ?> 
                                    <form method="POST" action="<?php echo e(route('admin.crud.destroy', [$table, $rowId])); ?>"
                                          onsubmit="return confirm('¿Eliminar este registro? Esta acción no se puede deshacer.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="p-2 rounded-lg text-red-500 hover:bg-red-50" title="Eliminar">
                                            <?php echo $__env->make('partials.icon', ['name' => 'trash', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>

                                <?php if($hasMore): ?>
                                    
                                    <template id="detail-<?php echo e($table); ?>-<?php echo e($loop->index); ?>">
                                        <?php
                                            $fileCols = collect($detailColumns)->filter(fn ($c) => $c['type'] === 'file');
                                            $otherCols = collect($detailColumns)->reject(fn ($c) => $c['type'] === 'file');
                                        ?>
                                        <div class="text-left">
                                            <?php $__currentLoopData = $fileCols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mb-5 flex justify-center bg-creamdark/40 rounded-xl p-4">
                                                    <?php echo $__env->make('admin.crud._cell', ['col' => $col, 'row' => $row, 'fkMaps' => $fkMaps, 'detail' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <dl class="grid sm:grid-cols-2 gap-x-6 gap-y-4">
                                                <?php $__currentLoopData = $otherCols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="<?php echo e($col['type'] === 'textarea' ? 'sm:col-span-2' : ''); ?>">
                                                        <dt class="text-[11px] uppercase tracking-wider text-muted"><?php echo e($col['label']); ?></dt>
                                                        <dd class="text-sm text-ink mt-0.5 whitespace-normal">
                                                            <?php echo $__env->make('admin.crud._cell', ['col' => $col, 'row' => $row, 'fkMaps' => $fkMaps, 'detail' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                        </dd>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </dl>
                                        </div>
                                    </template>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e(count($listColumns) + 1); ?>" class="px-5 py-12 text-center text-muted">
                                <?php if($q !== '' || collect(request()->query())->keys()->contains(fn ($k) => str_starts_with($k, 'f_') && request($k) !== null && request($k) !== '')): ?>
                                    No se encontraron registros con esa búsqueda o filtro.
                                <?php else: ?>
                                    No hay registros todavía.
                                    <?php if (! (\App\Support\Alcance::soloLectura($table))): ?>
                                    <a href="<?php echo e(route('admin.crud.create', $table)); ?>" class="text-olive-600 font-medium hover:underline">Crear el primero</a>.
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($rows->hasPages()): ?>
            <div class="px-5 py-4 border-t border-olive-100 js-paginacion">
                <?php echo e($rows->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\visilux_3\resources\views/admin/crud/_table.blade.php ENDPATH**/ ?>