<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión | VisiOptica</title>
    <link rel="icon" type="image/png" href="{{ asset('assets/img/favicon.png') }}">

    <!-- Google Fonts y Bootstrap -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    
    <!-- Tus estilos personalizados -->
    <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Validación en línea: borde verde si coincide con los registros, rojo si no -->
    <style>
        .login-input.is-valid,
        .login-input.is-valid:focus { border-color: #198754; box-shadow: 0 0 0 .2rem rgba(25,135,84,.2); }
        .login-input.is-invalid,
        .login-input.is-invalid:focus { border-color: #dc3545; box-shadow: 0 0 0 .2rem rgba(220,53,69,.2); }
        .input-group:has(.login-input.is-valid) .input-group-text { border-color: #198754; color: #198754; }
        .input-group:has(.login-input.is-invalid) .input-group-text { border-color: #dc3545; color: #dc3545; }
        .input-group:has(.is-valid) .input-group-text i,
        .input-group:has(.is-invalid) .input-group-text i { color: inherit !important; }
    </style>
</head>
<body class="login-page">

    <div class="login-bg"></div>

    <div class="container min-vh-100 d-flex align-items-center justify-content-center py-5">
        <div class="card login-card border-0 shadow-lg w-100" style="max-width: 420px;">
            <div class="card-body p-4 p-md-5">

                <!-- LOGO Y ENCABEZADO -->
                <div class="text-center mb-4">
                    <a href="{{ url('/') }}" class="text-decoration-none d-inline-block">
                        <img src="{{ asset('assets/img/logo-visilux.png') }}" alt="VisiOptica" class="login-logo img-fluid">
                    </a>
                    <p class="text-muted small mt-2 mb-0">
                        Accede a tu panel de paciente
                    </p>
                </div>

                <!-- MENSAJES DE ERROR -->
                @if (session('status'))
                    <div class="alert alert-success py-2 small" role="alert">
                        {{ session('status') }}
                    </div>
                @endif

                <!-- ÓPTICA SIN LICENCIA VIGENTE O SUSPENDIDA -->
                @if ($bloqueo = session('licencia_bloqueada'))
                    <div class="alert alert-warning small" role="alert">
                        <i class="bi bi-lock-fill me-1"></i>
                        {{ $bloqueo['mensaje'] }}
                        @if ($bloqueo['renovar_nit'])
                            <a href="{{ route('renovar.create', ['nit' => $bloqueo['renovar_nit']]) }}"
                               class="btn btn-sm btn-gradient rounded-pill w-100 mt-2">
                                Renovar mi plan
                            </a>
                        @endif
                    </div>
                @endif

                <!-- FORMULARIO -->
                <form method="POST" action="{{ route('login') }}" novalidate>
                    @csrf

                    <div class="mb-3">
                        <label for="email" class="form-label fw-medium">Correo electrónico</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0">
                                <i class="bi bi-envelope text-muted"></i>
                            </span>
                            <input type="email" 
                                   class="form-control border-start-0 login-input @error('email') is-invalid @enderror" 
                                   id="email" 
                                   name="email" 
                                   value="{{ old('email') }}" 
                                   placeholder="tu@correo.com" 
                                   required 
                                   autofocus>
                        </div>
                        <div id="email-feedback" class="small mt-1" aria-live="polite"></div>
                        @error('email')
                            <span class="invalid-feedback d-block" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label fw-medium">Contraseña</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0">
                                <i class="bi bi-lock text-muted"></i>
                            </span>
                            <input type="password" 
                                   class="form-control border-start-0 login-input @error('password') is-invalid @enderror" 
                                   id="password" 
                                   name="password" 
                                   placeholder="••••••••" 
                                   required>
                        </div>
                        <div id="password-feedback" class="small mt-1" aria-live="polite"></div>
                        @error('password')
                            <span class="invalid-feedback d-block" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                            <label class="form-check-label small" for="remember">Recordarme</label>
                        </div>

                        @if (Route::has('password.request'))
                            <a href="{{ route('password.request') }}" class="small link-teal text-decoration-none">
                                ¿Olvidaste tu contraseña?
                            </a>
                        @endif
                    </div>

                    <button type="submit" class="btn btn-gradient w-100 rounded-pill py-2 fw-semibold mb-3">
                        Iniciar sesión
                    </button>

                    <a href="{{ url('/') }}" class="btn btn-outline-secondary w-100 rounded-pill py-2 fw-semibold text-decoration-none text-center">
                        &larr; Volver al menú
                    </a>
                </form>

            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Validación en línea del login -->
    <script>
    (function () {
        const token    = document.querySelector('meta[name="csrf-token"]').content;
        const email    = document.getElementById('email');
        const password = document.getElementById('password');
        const fbEmail  = document.getElementById('email-feedback');
        const fbPass   = document.getElementById('password-feedback');
        const URL_EMAIL = "{{ route('login.verificar-email') }}";
        const URL_PASS  = "{{ route('login.verificar-password') }}";
        const formatoEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Pinta el campo: true = verde, false = rojo, null = sin color
        function marcar(input, fb, ok, mensaje) {
            input.classList.remove('is-valid', 'is-invalid');
            fb.className = 'small mt-1';
            fb.textContent = '';
            // Quita el mensaje del servidor (@error) apenas el usuario corrige
            const errServidor = input.closest('.mb-3').querySelector('.invalid-feedback');
            if (errServidor) errServidor.remove();
            if (ok === null) return;
            input.classList.add(ok ? 'is-valid' : 'is-invalid');
            fb.classList.add(ok ? 'text-success' : 'text-danger');
            fb.textContent = mensaje;
        }

        async function consultar(url, datos) {
            const resp = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': token
                },
                body: JSON.stringify(datos)
            });
            if (!resp.ok) throw new Error(resp.status);
            return resp.json();
        }

        // Espera a que el usuario deje de escribir antes de consultar
        function retrasar(fn, ms) {
            let t;
            return function () { clearTimeout(t); t = setTimeout(fn, ms); };
        }

        let emailRegistrado = false;
        let ultimaConsulta = 0;

        async function validarEmail() {
            const valor = email.value.trim();
            emailRegistrado = false;
            if (valor === '') { marcar(email, fbEmail, null); return validarPassword(); }
            if (!formatoEmail.test(valor)) {
                marcar(email, fbEmail, false, 'Escribe un correo válido.');
                return validarPassword();
            }
            const id = ++ultimaConsulta;
            try {
                const r = await consultar(URL_EMAIL, { email: valor });
                if (id !== ultimaConsulta) return; // llegó una respuesta vieja
                emailRegistrado = r.existe;
                marcar(email, fbEmail, r.existe,
                    r.existe ? 'Correo registrado.' : 'Este correo no está registrado.');
            } catch (e) {
                marcar(email, fbEmail, null); // si falla la consulta, no se pinta nada
            }
            validarPassword();
        }

        let ultimaPass = 0;

        async function validarPassword() {
            const valor = password.value;
            if (valor === '' || !emailRegistrado) { marcar(password, fbPass, null); return; }
            const id = ++ultimaPass;
            try {
                const r = await consultar(URL_PASS, { email: email.value.trim(), password: valor });
                if (id !== ultimaPass) return;
                marcar(password, fbPass, r.coincide,
                    r.coincide ? 'Contraseña correcta.' : 'La contraseña no coincide.');
            } catch (e) {
                // 429 = demasiados intentos
                marcar(password, fbPass, null);
                if (String(e.message) === '429') {
                    fbPass.className = 'small mt-1 text-warning';
                    fbPass.textContent = 'Demasiados intentos, espera un minuto.';
                }
            }
        }

        email.addEventListener('input', retrasar(validarEmail, 500));
        email.addEventListener('blur', validarEmail);
        password.addEventListener('input', retrasar(validarPassword, 700));
        password.addEventListener('blur', validarPassword);

        // Si el formulario vuelve con el correo ya escrito (old('email')), validarlo al cargar
        if (email.value.trim() !== '') validarEmail();
    })();
    </script>
</body>
</html>