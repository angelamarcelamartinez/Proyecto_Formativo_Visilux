<?php echo $__env->make('includes.cookies-banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<footer class="site-footer text-white mt-5" id="contacto">
    <div class="container py-5">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="footer-logo-wrap mb-3">
                    <img src="<?php echo e($sitio?->imagen('logo') ?? asset('assets/img/logo-visilux.png')); ?>" alt="<?php echo e($sitioEmpresa->nombre ?? 'VisiOptica'); ?>" class="footer-logo">
                </div>
                <p class="footer-text opacity-90">
                    <?php echo e($sitio->footer_texto ?? ''); ?>

                </p>
                <div class="d-flex gap-2">
                    <?php if($sitio?->instagram): ?>
                        <a href="<?php echo e($sitio->instagram); ?>" target="_blank" rel="noopener" class="social-btn" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
                    <?php endif; ?>
                    <?php if($sitio?->facebook): ?>
                        <a href="<?php echo e($sitio->facebook); ?>" target="_blank" rel="noopener" class="social-btn" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-lg-4">
                <h5 class="fw-semibold mb-3">Suscríbete a nuestro boletín</h5>
                <p class="footer-text small opacity-90 mb-3">
                    Recibe consejos de salud visual y promociones exclusivas.
                </p>
                <form class="newsletter-form d-flex gap-2" action="#" method="post" onsubmit="return false;">
                    <input type="email" class="form-control rounded-pill border-0" placeholder="correo electrónico" required>
                    <button type="submit" class="btn btn-light rounded-pill px-4 fw-semibold text-primary flex-shrink-0">
                        Suscribirse
                    </button>
                </form>
            </div>

            <div class="col-lg-2">
                <h5 class="fw-semibold mb-3">Horario</h5>
                <ul class="list-unstyled footer-text small opacity-90">
                    <?php $__currentLoopData = $sitio ? $sitio->lineas('horario') : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e($loop->last ? '' : 'mb-2'); ?>"><?php echo e($linea); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="col-lg-2">
                <h5 class="fw-semibold mb-3">Contacto</h5>
                <ul class="list-unstyled footer-text small opacity-90">
                    <?php if($sitio?->telefono): ?>
                        <li class="mb-2"><i class="bi bi-telephone me-2"></i> <?php echo e($sitio->telefono); ?></li>
                    <?php endif; ?>
                    <?php if($sitio?->email): ?>
                        <li class="mb-2"><i class="bi bi-envelope me-2"></i> <?php echo e($sitio->email); ?></li>
                    <?php endif; ?>
                    <?php if($sitio?->direccion): ?>
                        <li><i class="bi bi-geo-alt me-2"></i> <?php echo e($sitio->direccion); ?></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="footer-bottom text-center py-3">
        <small>
            &copy; <?php echo e(date('Y')); ?> <?php echo e($sitioEmpresa->nombre ?? 'Visilux'); ?>. Todos los derechos reservados.
        </small>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\visilux_3\resources\views/includes/footer.blade.php ENDPATH**/ ?>