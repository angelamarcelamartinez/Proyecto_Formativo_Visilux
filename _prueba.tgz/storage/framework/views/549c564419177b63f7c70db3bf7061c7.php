<?php $__env->startSection('title', 'Ópticas'); ?>
<?php $__env->startSection('breadcrumb', 'Ópticas'); ?>

<?php $__env->startSection('content'); ?>

    <?php
        $filtros = [
            'todas' => 'Todas',
            'vigente' => 'Vigentes',
            'por_vencer' => 'Por vencer',
            'vencida' => 'Vencidas',
            'sin_licencia' => 'Sin licencia',
        ];
    ?>

    <div class="flex items-end justify-between flex-wrap gap-4 mb-6">
        <div>
            <h1 class="font-serif text-2xl">Ópticas</h1>
            <p class="text-sm text-muted">Cada cliente de VisiOptica con su plan, días de licencia y estado.</p>
        </div>
        <a href="<?php echo e(route('superadmin.empresas.create')); ?>"
           class="inline-flex items-center gap-2 bg-olive-600 hover:bg-olive-700 transition text-cream text-sm font-medium px-4 py-2.5 rounded-xl shadow-card">
            <?php echo $__env->make('partials.icon', ['name' => 'plus', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            Registrar óptica
        </a>
    </div>

    <div class="bg-white rounded-2xl border border-olive-100 shadow-card overflow-hidden">
        <div class="px-5 sm:px-6 py-4 flex items-center justify-between flex-wrap gap-3 border-b border-olive-100">
            <div class="flex items-center gap-1 bg-creamdark/70 rounded-full p-1 overflow-x-auto">
                <?php $__currentLoopData = $filtros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $n = $key === 'todas' ? $conteos->sum() : ($conteos[$key] ?? 0); ?>
                    <a href="<?php echo e(route('superadmin.empresas.index', array_filter(['estado' => $key, 'q' => $q]))); ?>"
                       class="shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap
                              <?php echo e($estado === $key ? 'bg-white text-olive-700 shadow-sm ring-1 ring-olive-100' : 'text-ink/60 hover:text-ink'); ?>">
                        <?php echo e($label); ?> <span class="tabular-nums text-muted"><?php echo e($n); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if($q !== ''): ?>
                <p class="text-xs text-muted">
                    Resultados para «<?php echo e($q); ?>» ·
                    <a href="<?php echo e(route('superadmin.empresas.index', ['estado' => $estado])); ?>" class="text-olive-600 font-semibold">Quitar búsqueda</a>
                </p>
            <?php endif; ?>
        </div>

        <?php if($opticas->isEmpty()): ?>
            <div class="px-6 py-14 text-center">
                <div class="mx-auto w-14 h-14 rounded-2xl bg-creamdark text-olive-600 flex items-center justify-center mb-4">
                    <?php echo $__env->make('partials.icon', ['name' => 'building', 'class' => 'w-6 h-6'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <p class="font-serif text-lg">No hay ópticas con este filtro</p>
                <p class="text-sm text-muted mt-1">Prueba con otro estado o busca por otro nombre.</p>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-cream text-left text-[11px] uppercase tracking-wider text-muted">
                            <th class="py-3 pl-6 pr-4 font-semibold">Óptica</th>
                            <th class="py-3 pr-4 font-semibold">Correo</th>
                            <th class="py-3 pr-4 font-semibold">Plan</th>
                            <th class="py-3 pr-4 font-semibold">Desde</th>
                            <th class="py-3 pr-4 font-semibold">Vence</th>
                            <th class="py-3 pr-4 font-semibold">Días restantes</th>
                            <th class="py-3 pr-4 font-semibold">Usuarios</th>
                            <th class="py-3 pr-4 font-semibold">Estado</th>
                            <th class="py-3 pr-6 font-semibold text-right">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-olive-100">
                        <?php $__currentLoopData = $opticas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-cream/70 transition">
                                <td class="py-3 pl-6 pr-4">
                                    <a href="<?php echo e(route('superadmin.empresas.show', $o->nit)); ?>" class="font-medium whitespace-nowrap hover:text-olive-700"><?php echo e($o->empresa); ?></a>
                                    <p class="text-[11px] text-muted">NIT <?php echo e($o->nit); ?></p>
                                </td>
                                <td class="py-3 pr-4 text-ink/70 whitespace-nowrap"><?php echo e($o->email); ?></td>
                                <td class="py-3 pr-4 whitespace-nowrap">
                                    <?php echo e($o->plan ?? '—'); ?>

                                    <?php if($o->es_prueba): ?>
                                        <span class="text-[10px] font-semibold uppercase text-sky-700 bg-sky-50 rounded px-1.5 py-0.5 ml-1">Prueba</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 pr-4 whitespace-nowrap text-ink/70 tabular-nums">
                                    <?php echo e($o->fecha_inicio ? \Illuminate\Support\Carbon::parse($o->fecha_inicio)->format('d/m/Y') : '—'); ?>

                                </td>
                                <td class="py-3 pr-4 whitespace-nowrap text-ink/70 tabular-nums">
                                    <?php echo e($o->fecha_fin ? \Illuminate\Support\Carbon::parse($o->fecha_fin)->format('d/m/Y') : '—'); ?>

                                </td>
                                <td class="py-3 pr-4">
                                    <?php echo $__env->make('partials.estado-licencia', ['dias' => $o->dias_restantes !== null ? (int) $o->dias_restantes : null, 'solo' => 'dias'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </td>
                                <td class="py-3 pr-4 tabular-nums text-ink/80"><?php echo e($o->usuarios_registrados); ?></td>
                                <td class="py-3 pr-4">
                                    <?php echo $__env->make('partials.estado-licencia', ['estado' => $o->estado_licencia, 'solo' => 'estado'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </td>
                                <td class="py-3 pr-6">
                                    <div class="flex items-center justify-end gap-1">
                                        <a href="<?php echo e(route('superadmin.empresas.show', $o->nit)); ?>" title="Ver detalle"
                                           class="p-2 rounded-lg text-ink/60 hover:bg-olive-100 hover:text-olive-700 transition">
                                            <?php echo $__env->make('partials.icon', ['name' => 'eye', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </a>
                                        <a href="<?php echo e(route('superadmin.empresas.edit', $o->nit)); ?>" title="Editar datos"
                                           class="p-2 rounded-lg text-ink/60 hover:bg-olive-100 hover:text-olive-700 transition">
                                            <?php echo $__env->make('partials.icon', ['name' => 'pencil', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    
    <?php
        $dinero = fn ($v) => '$' . number_format((float) $v, 0, ',', '.');
        $filtrosLic = ['todas' => 'Todas', 'activa' => 'Activas', 'vencida' => 'Vencidas', 'cancelada' => 'Canceladas'];
    ?>
    <div id="historial" class="bg-white rounded-2xl border border-olive-100 shadow-card overflow-hidden mt-8 scroll-mt-24">
        <div class="px-5 sm:px-6 py-4 flex items-center justify-between flex-wrap gap-3 border-b border-olive-100">
            <div>
                <h3 class="font-serif text-lg">Historial de licencias</h3>
                <p class="text-xs text-muted">Pruebas, compras y renovaciones de todas las ópticas</p>
            </div>
            <div class="flex items-center gap-1 bg-creamdark/70 rounded-full p-1 overflow-x-auto">
                <?php $__currentLoopData = $filtrosLic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('superadmin.empresas.index', array_filter(['estado' => $estado !== 'todas' ? $estado : null, 'q' => $q, 'lic' => $key !== 'todas' ? $key : null]))); ?>#historial"
                       class="shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap
                              <?php echo e($estadoLic === $key ? 'bg-white text-olive-700 shadow-sm ring-1 ring-olive-100' : 'text-ink/60 hover:text-ink'); ?>">
                        <?php echo e($label); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-cream text-left text-[11px] uppercase tracking-wider text-muted">
                        <th class="py-3 pl-6 pr-4 font-semibold">Óptica</th>
                        <th class="py-3 pr-4 font-semibold">Plan</th>
                        <th class="py-3 pr-4 font-semibold">Periodo</th>
                        <th class="py-3 pr-4 font-semibold">Días</th>
                        <th class="py-3 pr-4 font-semibold">Valor</th>
                        <th class="py-3 pr-4 font-semibold">Referencia</th>
                        <th class="py-3 pr-6 font-semibold">Estado</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-olive-100">
                    <?php $__empty_1 = true; $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-cream/70 transition">
                            <td class="py-3 pl-6 pr-4 whitespace-nowrap">
                                <a href="<?php echo e(route('superadmin.empresas.show', $lic->nit_empresa)); ?>" class="font-medium hover:text-olive-700">
                                    <?php echo e($lic->empresa->nombre ?? $lic->nit_empresa); ?>

                                </a>
                            </td>
                            <td class="py-3 pr-4 whitespace-nowrap"><?php echo e($lic->plan->nombre ?? '—'); ?></td>
                            <td class="py-3 pr-4 whitespace-nowrap text-ink/70 tabular-nums">
                                <?php if($lic->fecha_inicio): ?>
                                    <?php echo e($lic->fecha_inicio->format('d/m/Y')); ?> – <?php echo e($lic->fecha_fin?->format('d/m/Y')); ?>

                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td class="py-3 pr-4">
                                <?php if($lic->estado === 'activa'): ?>
                                    <?php echo $__env->make('partials.estado-licencia', ['dias' => $lic->diasRestantes(), 'solo' => 'dias'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 pr-4 whitespace-nowrap tabular-nums"><?php echo e($dinero($lic->valor)); ?></td>
                            <td class="py-3 pr-4 text-ink/70"><?php echo e($lic->referencia_pago ?? '—'); ?></td>
                            <td class="py-3 pr-6"><?php echo $__env->make('partials.estado-licencia', ['estado' => $lic->estado, 'solo' => 'estado'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="px-6 py-10 text-center text-muted">No hay licencias con este filtro.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($historial->hasPages()): ?>
            <div class="px-6 py-4 border-t border-olive-100 flex items-center justify-between text-sm">
                <span class="text-muted">Página <?php echo e($historial->currentPage()); ?> de <?php echo e($historial->lastPage()); ?></span>
                <div class="flex gap-2">
                    <?php if($historial->previousPageUrl()): ?>
                        <a href="<?php echo e($historial->previousPageUrl()); ?>" class="px-3 py-1.5 rounded-lg border border-olive-100 hover:bg-olive-50">Anterior</a>
                    <?php endif; ?>
                    <?php if($historial->nextPageUrl()): ?>
                        <a href="<?php echo e($historial->nextPageUrl()); ?>" class="px-3 py-1.5 rounded-lg border border-olive-100 hover:bg-olive-50">Siguiente</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\visilux_3\resources\views/superadmin/empresas/index.blade.php ENDPATH**/ ?>