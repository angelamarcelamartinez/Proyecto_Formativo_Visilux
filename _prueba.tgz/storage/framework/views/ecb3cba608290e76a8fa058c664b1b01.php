<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Panel general'); ?> · VisiOptica</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.png')); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/panel.css')); ?>?v=<?php echo e(filemtime(public_path('assets/css/panel.css'))); ?>">
    <script defer src="<?php echo e(asset('assets/js/alpine-collapse.min.js')); ?>"></script>
    <script defer src="<?php echo e(asset('assets/js/alpine.min.js')); ?>"></script>
    <script defer src="<?php echo e(asset('assets/js/chart.umd.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="bg-cream text-ink antialiased">
<div class="min-h-screen flex" x-data="{ mobileNav: false }">

    
    <aside
        class="fixed inset-y-0 left-0 z-40 w-72 bg-creamdark border-r border-olive-100 flex flex-col transition-transform -translate-x-full lg:translate-x-0"
        :class="mobileNav && '!translate-x-0'"
    >
        <div class="h-20 flex items-center gap-3 px-6 border-b border-olive-100">
            <div class="w-9 h-9 rounded-full bg-ink text-cream flex items-center justify-center font-serif-heading text-sm">VO</div>
            <div>
                <p class="font-serif-heading text-lg leading-tight">VisiOptica</p>
                <p class="text-[11px] uppercase tracking-wider text-muted">Superadministrador</p>
            </div>
        </div>

        <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1">
            <?php
                $menu = [
                    ['route' => 'superadmin.dashboard', 'match' => 'superadmin.dashboard', 'icon' => 'grid', 'label' => 'Panel general', 'badge' => $solicitudesPendientes ?? 0],
                    ['route' => 'superadmin.empresas.index', 'match' => 'superadmin.empresas.*', 'icon' => 'building', 'label' => 'Ópticas'],
                    ['route' => 'superadmin.reportes.index', 'match' => 'superadmin.reportes.*', 'icon' => 'file-text', 'label' => 'Reportes'],
                    ['route' => 'superadmin.planes.index', 'match' => 'superadmin.planes.*', 'icon' => 'tag', 'label' => 'Planes'],
                ];
            ?>

            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route($item['route'])); ?>"
                   class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition
                          <?php echo e(request()->routeIs($item['match']) ? 'bg-olive-600 text-cream shadow-card' : 'text-ink/80 hover:bg-olive-100'); ?>">
                    <?php echo $__env->make('partials.icon', ['name' => $item['icon'], 'class' => 'w-5 h-5 shrink-0'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <span class="flex-1"><?php echo e($item['label']); ?></span>
                    <?php if(! empty($item['badge'])): ?>
                        <span class="text-[11px] font-semibold rounded-full px-2 py-0.5 bg-amber-100 text-amber-700 tabular-nums"><?php echo e($item['badge']); ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <p class="px-3 pt-5 pb-1 text-[11px] font-semibold uppercase tracking-wider text-muted">Accesos rápidos</p>

            <a href="<?php echo e(route('superadmin.empresas.create')); ?>"
               class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-ink/80 hover:bg-olive-100 transition">
                <?php echo $__env->make('partials.icon', ['name' => 'plus', 'class' => 'w-5 h-5 shrink-0'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                Registrar óptica
            </a>
            <a href="<?php echo e(url('/')); ?>" target="_blank"
               class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-ink/80 hover:bg-olive-100 transition">
                <?php echo $__env->make('partials.icon', ['name' => 'eye', 'class' => 'w-5 h-5 shrink-0'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                Ver sitio público
            </a>
        </nav>

        <div class="p-4 border-t border-olive-100">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="w-full flex items-center gap-2 justify-center px-3 py-2 rounded-lg text-sm font-medium text-ink/70 hover:bg-olive-100 transition">
                    <?php echo $__env->make('partials.icon', ['name' => 'logout', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    Cerrar sesión
                </button>
            </form>
        </div>
    </aside>

    
    <div x-show="mobileNav" @click="mobileNav = false" x-cloak class="fixed inset-0 bg-ink/30 z-30 lg:hidden"></div>

    
    <div class="flex-1 lg:ml-72 flex flex-col min-h-screen">

        
        <header class="h-20 sticky top-0 z-20 bg-cream/90 backdrop-blur border-b border-olive-100 flex items-center gap-4 px-4 sm:px-8">
            <button class="lg:hidden text-ink/70" @click="mobileNav = !mobileNav">
                <?php echo $__env->make('partials.icon', ['name' => 'grid', 'class' => 'w-6 h-6'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </button>

            <div class="hidden sm:flex items-center gap-1.5 text-sm font-medium text-olive-600">
                <?php echo $__env->yieldContent('breadcrumb', 'Panel general'); ?>
            </div>

            
            <form method="GET" action="<?php echo e(route('superadmin.empresas.index')); ?>" class="flex-1 max-w-md ml-auto relative">
                <span class="absolute inset-y-0 left-3 flex items-center text-muted pointer-events-none">
                    <?php echo $__env->make('partials.icon', ['name' => 'search', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </span>
                <input type="text" name="q" value="<?php echo e(request()->routeIs('superadmin.empresas.index') ? request('q') : ''); ?>"
                       placeholder="Buscar óptica por nombre, NIT o correo..."
                       class="w-full bg-creamdark/70 border border-olive-100 rounded-full py-2.5 pl-9 pr-4 text-sm placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-olive-300">
            </form>

            <div class="flex items-center gap-3 pl-2">
                <div class="text-right hidden sm:block">
                    <p class="text-sm font-semibold leading-tight"><?php echo e(auth()->user()->nombres ?? 'Administrador'); ?></p>
                    <p class="text-[11px] text-muted leading-tight"><?php echo e(auth()->user()->rol->nombre_rol ?? 'Superadmin'); ?></p>
                </div>
                <div class="w-10 h-10 rounded-full bg-ink text-cream flex items-center justify-center text-sm font-semibold">
                    <?php echo e(\Illuminate\Support\Str::of(auth()->user()->nombres ?? 'A')->explode(' ')->map(fn ($p) => mb_substr($p, 0, 1))->take(2)->implode('')); ?>

                </div>
            </div>
        </header>

        <main class="flex-1 px-4 sm:px-8 py-6">
            <?php if(session('success')): ?>
                <div class="mb-6 rounded-xl border border-green-200 bg-green-50 text-green-800 px-4 py-3 text-sm">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            
            <?php if (! empty(trim($__env->yieldContent('errores_en_formulario')))): ?>
            <?php else: ?>
                <?php if($errors->any()): ?>
                    <div class="mb-6 rounded-xl border border-red-200 bg-red-50 text-red-700 px-4 py-3 text-sm space-y-0.5">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\visilux_3\resources\views/layouts/superadmin.blade.php ENDPATH**/ ?>