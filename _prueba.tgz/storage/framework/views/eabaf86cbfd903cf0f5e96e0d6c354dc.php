<?php $__env->startSection('title', 'Panel general'); ?>
<?php $__env->startSection('breadcrumb', 'Panel general'); ?>

<?php $__env->startSection('content'); ?>

    <?php
        $dinero = fn ($v) => $v >= 1000000
            ? '$' . number_format($v / 1000000, 1, ',', '.') . 'M'
            : '$' . number_format($v, 0, ',', '.');

        $dineroCompleto = fn ($v) => '$' . number_format((float) $v, 0, ',', '.');
        $campo = 'bg-creamdark/40 border border-olive-100 rounded-lg py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-olive-300';
    ?>

    <div class="flex items-end justify-between flex-wrap gap-4 mb-6">
        <div>
            <h1 class="font-serif text-2xl">Panel general</h1>
            <p class="text-sm text-muted">Aprueba los pagos de las ópticas y revisa las cifras clave de VisiOptica.</p>
        </div>
        <a href="<?php echo e(route('superadmin.empresas.create')); ?>"
           class="inline-flex items-center gap-2 bg-olive-600 hover:bg-olive-700 transition text-cream text-sm font-medium px-4 py-2.5 rounded-xl shadow-card">
            <?php echo $__env->make('partials.icon', ['name' => 'plus', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            Registrar óptica
        </a>
    </div>

    
    <div class="bg-white rounded-2xl border border-olive-100 shadow-card overflow-hidden mb-8">
        <div class="px-5 sm:px-6 pt-5 pb-4 border-b border-olive-100 flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center">
                <?php echo $__env->make('partials.icon', ['name' => 'receipt', 'class' => 'w-4.5 h-4.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div>
                <h3 class="font-serif text-lg leading-tight flex items-center gap-2">
                    Pagos por aprobar
                    <span class="text-[11px] font-sans font-semibold rounded-full px-2 py-0.5 tabular-nums
                                 <?php echo e($pendientes->count() > 0 ? 'bg-amber-100 text-amber-700' : 'bg-creamdark text-olive-700'); ?>"><?php echo e($pendientes->count()); ?></span>
                </h3>
                <p class="text-xs text-muted">Al aprobar, el plan empieza hoy o cuando termine el que la óptica ya tiene.</p>
            </div>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $pendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="px-5 sm:px-6 py-4 border-b border-olive-100 last:border-b-0 flex flex-col lg:flex-row lg:items-center gap-4">
                <div class="lg:w-72 shrink-0">
                    <a href="<?php echo e(route('superadmin.empresas.show', $lic->nit_empresa)); ?>" class="font-medium hover:text-olive-700">
                        <?php echo e($lic->empresa->nombre ?? $lic->nit_empresa); ?>

                    </a>
                    <p class="text-xs text-muted">
                        <?php echo e($lic->plan->nombre ?? 'Plan'); ?> · <?php echo e($dineroCompleto($lic->valor)); ?> · pedida el <?php echo e($lic->fecha_solicitud?->format('d/m/Y')); ?>

                    </p>
                    <?php if($lic->empresa?->estaPendiente()): ?>
                        <span class="inline-block mt-1 text-[10px] font-semibold uppercase text-sky-700 bg-sky-50 rounded px-1.5 py-0.5">Óptica nueva</span>
                        <p class="text-[11px] text-muted mt-1"><?php echo e($lic->observaciones); ?></p>
                        <p class="text-[11px] text-muted">Ref. <?php echo e($lic->referencia_pago); ?></p>
                    <?php endif; ?>
                </div>

                <?php if($lic->empresa?->estaPendiente()): ?>
                    
                    <div class="flex flex-wrap items-center gap-3 flex-1">
                        <p class="text-xs text-muted flex-1 min-w-[10rem]">
                            Revisa el certificado de la Cámara de Comercio y confirma el NIT para aprobar. Se envía una contraseña temporal al correo de la óptica (<?php echo e($lic->empresa->email); ?>); el administrador entra con su propio correo y debe cambiarla.
                        </p>
                        <?php echo $__env->make('superadmin.partials.modal-camara', ['empresa' => $lic->empresa, 'licencia' => $lic], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php else: ?>
                    <form method="POST" action="<?php echo e(route('superadmin.licencias.aprobar', $lic->id_licencia)); ?>" class="flex flex-wrap items-center gap-2 flex-1">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="referencia_pago" placeholder="Referencia del pago" class="<?php echo e($campo); ?> flex-1 min-w-[10rem]">
                        <input type="number" name="valor" min="0" step="1" value="<?php echo e((int) $lic->valor); ?>" title="Valor recibido" class="<?php echo e($campo); ?> w-32">
                        <button type="submit" class="bg-olive-600 hover:bg-olive-700 transition text-cream text-sm font-medium px-4 py-2 rounded-lg">Aprobar pago</button>
                    </form>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('superadmin.licencias.rechazar', $lic->id_licencia)); ?>"
                      onsubmit="return confirm('<?php echo e($lic->empresa?->estaPendiente()
                          ? '¿Rechazar el registro de ' . addslashes($lic->empresa->nombre) . '? Se borrarán la óptica y su administrador.'
                          : '¿Rechazar la solicitud de ' . addslashes($lic->empresa->nombre ?? '') . '?'); ?>')">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-sm font-medium text-rose-600 hover:text-rose-800 px-2 py-2">Rechazar</button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="px-6 py-10 text-center text-sm text-muted">No hay pagos por aprobar.</div>
        <?php endif; ?>
    </div>

    
    <?php
        $stats = [
            [
                'icon' => 'building', 'value' => $totalOpticas, 'label' => 'Ópticas registradas',
                'hint' => 'Todas las cuentas', 'tone' => 'bg-olive-100 text-olive-700', 'bar' => 'bg-olive-500',
                'link' => route('superadmin.empresas.index'),
            ],
            [
                'icon' => 'shield', 'value' => $vigentes, 'label' => 'Licencia vigente',
                'hint' => 'Más de ' . config('visioptica.dias_aviso') . ' días', 'tone' => 'bg-emerald-50 text-emerald-700', 'bar' => 'bg-emerald-500',
                'link' => route('superadmin.empresas.index', ['estado' => 'vigente']),
            ],
            [
                'icon' => 'clock', 'value' => $porVencer, 'label' => 'Por vencer',
                'hint' => config('visioptica.dias_aviso') . ' días o menos', 'tone' => 'bg-amber-50 text-amber-700', 'bar' => 'bg-amber-500',
                'link' => route('superadmin.empresas.index', ['estado' => 'por_vencer']),
            ],
            [
                'icon' => 'lock', 'value' => $vencidas, 'label' => 'Vencidas o sin plan',
                'hint' => $vencidas > 0 ? 'No pueden entrar al panel' : 'Ninguna bloqueada',
                'tone' => $vencidas > 0 ? 'bg-rose-50 text-rose-700' : 'bg-olive-100 text-olive-700',
                'bar' => $vencidas > 0 ? 'bg-rose-500' : 'bg-olive-500', 'alert' => $vencidas > 0,
                'link' => route('superadmin.empresas.index', ['estado' => 'vencida']),
            ],
            [
                'icon' => 'receipt', 'value' => $dinero($ingresosMes), 'label' => 'Ingresos del mes',
                'hint' => 'Pagos aprobados', 'tone' => 'bg-sky-50 text-sky-700', 'bar' => 'bg-sky-500',
                'link' => route('superadmin.reportes.index') . '#ingresos',
            ],
        ];
    ?>

    <div class="grid grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5 gap-4 sm:gap-5">
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($stat['link']); ?>"
               class="group relative overflow-hidden bg-white rounded-2xl border border-olive-100 shadow-card p-5 sm:p-6 flex flex-col
                      hover:-translate-y-0.5 hover:border-olive-300 hover:shadow-lg transition duration-200">
                <span class="absolute inset-x-0 top-0 h-1 <?php echo e($stat['bar']); ?> opacity-80"></span>

                <div class="flex items-start justify-between mb-5">
                    <div class="w-11 h-11 rounded-xl <?php echo e($stat['tone']); ?> flex items-center justify-center">
                        <?php echo $__env->make('partials.icon', ['name' => $stat['icon'], 'class' => 'w-5 h-5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>

                    <?php if(! empty($stat['alert'])): ?>
                        <span class="relative flex h-2.5 w-2.5 mt-1">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-60"></span>
                            <span class="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
                        </span>
                    <?php else: ?>
                        <span class="text-[11px] font-medium text-olive-600 opacity-70 group-hover:opacity-100 transition flex items-center gap-1">
                            Ver <span class="transition group-hover:translate-x-0.5">→</span>
                        </span>
                    <?php endif; ?>
                </div>

                <p class="font-serif text-3xl sm:text-[34px] leading-none tabular-nums text-ink"><?php echo e($stat['value']); ?></p>
                <p class="text-sm font-medium text-ink/80 mt-2"><?php echo e($stat['label']); ?></p>
                <p class="text-xs text-muted mt-0.5"><?php echo e($stat['hint']); ?></p>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\visilux_3\resources\views/superadmin/dashboard.blade.php ENDPATH**/ ?>