<?php $__env->startSection('title', 'Reportes'); ?>
<?php $__env->startSection('breadcrumb', 'Reportes'); ?>

<?php $__env->startSection('content'); ?>

    <?php
        $dinero = fn ($v) => '$' . number_format((float) $v, 0, ',', '.');
        $campo = 'bg-creamdark/40 border border-olive-100 rounded-lg py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-olive-300';
        $botonDescarga = 'inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg border border-olive-100 bg-white hover:bg-olive-50 text-olive-700 transition';

        // Cada filtro conserva lo que el superadmin eligió en las otras secciones
        $conservar = fn (array $propios) => collect(request()->except(array_merge($propios, ['page', 'act'])))
            ->filter(fn ($v) => is_scalar($v) && $v !== '' && $v !== null);

        $filtrosEstado = [
            'todas' => 'Todas', 'vigente' => 'Vigentes', 'por_vencer' => 'Por vencer',
            'vencida' => 'Vencidas', 'sin_licencia' => 'Sin licencia',
        ];
    ?>

    <div class="mb-6">
        <h1 class="font-serif text-2xl">Reportes</h1>
        <p class="text-sm text-muted">Ingresos, ópticas, actividad y las ópticas que necesitan un aviso. Los reportes de ingresos y de ópticas se descargan en Excel y PDF.</p>
    </div>

    
    <div class="flex items-center gap-1 bg-creamdark/70 rounded-full p-1 overflow-x-auto mb-8 w-fit max-w-full">
        <?php $__currentLoopData = ['atencion' => 'Requieren atención', 'ingresos' => 'Ingresos por licencias', 'reporte-opticas' => 'Ópticas', 'actividad' => 'Registro de actividad']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="#<?php echo e($id); ?>" class="shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium text-ink/70 hover:text-ink hover:bg-white transition whitespace-nowrap"><?php echo e($label); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div id="atencion" class="bg-white rounded-2xl border border-olive-100 shadow-card overflow-hidden mb-8 scroll-mt-24">
        <div class="px-5 sm:px-6 pt-5 pb-4 border-b border-olive-100 flex items-center gap-3 flex-wrap">
            <div class="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
                <?php echo $__env->make('partials.icon', ['name' => 'clock', 'class' => 'w-4.5 h-4.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="flex-1 min-w-[12rem]">
                <h3 class="font-serif text-lg leading-tight flex items-center gap-2">
                    Requieren atención
                    <span class="text-[11px] font-sans font-semibold bg-creamdark text-olive-700 rounded-full px-2 py-0.5 tabular-nums"><?php echo e($alertas->count()); ?></span>
                </h3>
                <p class="text-xs text-muted">Por vencer, vencidas o sin plan</p>
            </div>
            <form method="POST" action="<?php echo e(route('superadmin.avisos')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" title="Envía el correo de vencimiento a las ópticas a las que les toca hoy"
                        class="inline-flex items-center gap-1.5 text-sm font-semibold text-cream bg-olive-600 hover:bg-olive-700 rounded-xl px-4 py-2.5 shadow-card transition">
                    <?php echo $__env->make('partials.icon', ['name' => 'mail', 'class' => 'w-4 h-4'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    Enviar avisos
                </button>
            </form>
        </div>

        <?php if($alertas->isEmpty()): ?>
            <div class="px-6 py-10 text-center text-sm text-muted">Todas las ópticas están al día.</div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-cream text-left text-[11px] uppercase tracking-wider text-muted">
                            <th class="py-3 pl-6 pr-4 font-semibold">Óptica</th>
                            <th class="py-3 pr-4 font-semibold">Correo</th>
                            <th class="py-3 pr-4 font-semibold">Plan</th>
                            <th class="py-3 pr-4 font-semibold">Vence</th>
                            <th class="py-3 pr-4 font-semibold">Días</th>
                            <th class="py-3 pr-6 font-semibold">Estado</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-olive-100">
                        <?php $__currentLoopData = $alertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-cream/70 transition">
                                <td class="py-3 pl-6 pr-4 whitespace-nowrap">
                                    <a href="<?php echo e(route('superadmin.empresas.show', $o->nit)); ?>" class="font-medium hover:text-olive-700"><?php echo e($o->empresa); ?></a>
                                    <p class="text-[11px] text-muted">NIT <?php echo e($o->nit); ?></p>
                                </td>
                                <td class="py-3 pr-4 text-ink/70 whitespace-nowrap"><?php echo e($o->email); ?></td>
                                <td class="py-3 pr-4 whitespace-nowrap"><?php echo e($o->plan ?? 'Sin plan'); ?></td>
                                <td class="py-3 pr-4 whitespace-nowrap text-ink/70 tabular-nums"><?php echo e($o->fecha_fin ? \Illuminate\Support\Carbon::parse($o->fecha_fin)->format('d/m/Y') : '—'); ?></td>
                                <td class="py-3 pr-4"><?php echo $__env->make('partials.estado-licencia', ['dias' => $o->dias_restantes !== null ? (int) $o->dias_restantes : null, 'solo' => 'dias'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                                <td class="py-3 pr-6"><?php echo $__env->make('partials.estado-licencia', ['estado' => $o->estado_licencia, 'solo' => 'estado'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    
    <div id="ingresos" class="bg-white rounded-2xl border border-olive-100 shadow-card overflow-hidden mb-8 scroll-mt-24">
        <div class="px-5 sm:px-6 pt-5 pb-4 border-b border-olive-100 flex items-center gap-3 flex-wrap">
            <div class="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <?php echo $__env->make('partials.icon', ['name' => 'receipt', 'class' => 'w-4.5 h-4.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="flex-1 min-w-[12rem]">
                <h3 class="font-serif text-lg leading-tight">Ingresos por licencias</h3>
                <p class="text-xs text-muted">Pagos aprobados, mes a mes</p>
            </div>
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('superadmin.reportes.descargar', ['reporte' => 'ingresos', 'formato' => 'excel', 'desde' => $desde, 'hasta' => $hasta])); ?>" class="<?php echo e($botonDescarga); ?>">
                    <?php echo $__env->make('partials.icon', ['name' => 'download', 'class' => 'w-3.5 h-3.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    Excel
                </a>
                <a href="<?php echo e(route('superadmin.reportes.descargar', ['reporte' => 'ingresos', 'formato' => 'pdf', 'desde' => $desde, 'hasta' => $hasta])); ?>" class="<?php echo e($botonDescarga); ?>">
                    <?php echo $__env->make('partials.icon', ['name' => 'download', 'class' => 'w-3.5 h-3.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    PDF
                </a>
            </div>
        </div>

        <div class="p-5 sm:p-6">
            <form method="GET" action="<?php echo e(route('superadmin.reportes.index')); ?>#ingresos" class="flex flex-wrap items-end gap-3 mb-6">
                <?php $__currentLoopData = $conservar(['desde', 'hasta']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <label class="text-xs text-muted">Desde
                    <input type="month" name="desde" value="<?php echo e($desde); ?>" class="<?php echo e($campo); ?> block mt-1">
                </label>
                <label class="text-xs text-muted">Hasta
                    <input type="month" name="hasta" value="<?php echo e($hasta); ?>" class="<?php echo e($campo); ?> block mt-1">
                </label>
                <button type="submit" class="bg-olive-600 hover:bg-olive-700 transition text-cream text-sm font-medium px-4 py-2 rounded-lg">Ver</button>
            </form>

            <div class="grid grid-cols-2 gap-4 mb-6 max-w-xl">
                <div class="rounded-xl bg-creamdark/60 border border-olive-100 px-4 py-3">
                    <p class="text-xs text-muted">Total del periodo</p>
                    <p class="font-serif text-2xl tabular-nums mt-1"><?php echo e($dinero($totalIngresos)); ?></p>
                </div>
                <div class="rounded-xl bg-creamdark/60 border border-olive-100 px-4 py-3">
                    <p class="text-xs text-muted">Pagos aprobados</p>
                    <p class="font-serif text-2xl tabular-nums mt-1"><?php echo e($cantidadPagos); ?></p>
                </div>
            </div>

            <div class="grid lg:grid-cols-2 gap-6 items-start">
                <div class="h-64"><canvas id="graficaIngresos"></canvas></div>

                <div class="overflow-x-auto rounded-xl border border-olive-100">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="bg-cream text-left text-[11px] uppercase tracking-wider text-muted">
                                <th class="py-2.5 pl-4 pr-3 font-semibold">Mes</th>
                                <th class="py-2.5 pr-3 font-semibold text-right">Pagos</th>
                                <th class="py-2.5 pr-4 font-semibold text-right">Ingresos</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-olive-100">
                            <?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="py-2.5 pl-4 pr-3"><?php echo e($m['etiqueta']); ?></td>
                                    <td class="py-2.5 pr-3 text-right tabular-nums"><?php echo e($m['pagos']); ?></td>
                                    <td class="py-2.5 pr-4 text-right tabular-nums font-medium"><?php echo e($dinero($m['total'])); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="bg-cream font-semibold">
                                <td class="py-2.5 pl-4 pr-3">Total</td>
                                <td class="py-2.5 pr-3 text-right tabular-nums"><?php echo e($cantidadPagos); ?></td>
                                <td class="py-2.5 pr-4 text-right tabular-nums"><?php echo e($dinero($totalIngresos)); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <p class="text-[11px] text-muted mt-4">El Excel y el PDF traen el detalle de cada pago (óptica, plan, periodo, referencia y valor).</p>
        </div>
    </div>

    
    <div id="reporte-opticas" class="bg-white rounded-2xl border border-olive-100 shadow-card overflow-hidden mb-8 scroll-mt-24">
        <div class="px-5 sm:px-6 pt-5 pb-4 border-b border-olive-100 flex items-center gap-3 flex-wrap">
            <div class="w-9 h-9 rounded-xl bg-olive-100 text-olive-700 flex items-center justify-center">
                <?php echo $__env->make('partials.icon', ['name' => 'building', 'class' => 'w-4.5 h-4.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="flex-1 min-w-[12rem]">
                <h3 class="font-serif text-lg leading-tight flex items-center gap-2">
                    Reporte de ópticas
                    <span class="text-[11px] font-sans font-semibold bg-creamdark text-olive-700 rounded-full px-2 py-0.5 tabular-nums"><?php echo e($opticas->count()); ?></span>
                </h3>
                <p class="text-xs text-muted">Plan, vencimiento y estado de cada óptica</p>
            </div>
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('superadmin.reportes.descargar', array_filter(['reporte' => 'opticas', 'formato' => 'excel', 'estado' => $estado !== 'todas' ? $estado : null]))); ?>" class="<?php echo e($botonDescarga); ?>">
                    <?php echo $__env->make('partials.icon', ['name' => 'download', 'class' => 'w-3.5 h-3.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    Excel
                </a>
                <a href="<?php echo e(route('superadmin.reportes.descargar', array_filter(['reporte' => 'opticas', 'formato' => 'pdf', 'estado' => $estado !== 'todas' ? $estado : null]))); ?>" class="<?php echo e($botonDescarga); ?>">
                    <?php echo $__env->make('partials.icon', ['name' => 'download', 'class' => 'w-3.5 h-3.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    PDF
                </a>
            </div>
        </div>

        <div class="px-5 sm:px-6 py-4 border-b border-olive-100">
            <div class="flex items-center gap-1 bg-creamdark/70 rounded-full p-1 overflow-x-auto w-fit max-w-full">
                <?php $__currentLoopData = $filtrosEstado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $n = $key === 'todas' ? $conteos->sum() : ($conteos[$key] ?? 0); ?>
                    <a href="<?php echo e(route('superadmin.reportes.index', $conservar(['estado'])->merge($key !== 'todas' ? ['estado' => $key] : [])->all())); ?>#reporte-opticas"
                       class="shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap
                              <?php echo e($estado === $key ? 'bg-white text-olive-700 shadow-sm ring-1 ring-olive-100' : 'text-ink/60 hover:text-ink'); ?>">
                        <?php echo e($label); ?> <span class="tabular-nums text-muted"><?php echo e($n); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <?php if($opticas->isEmpty()): ?>
            <div class="px-6 py-10 text-center text-sm text-muted">No hay ópticas con este filtro.</div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-cream text-left text-[11px] uppercase tracking-wider text-muted">
                            <th class="py-3 pl-6 pr-4 font-semibold">Óptica</th>
                            <th class="py-3 pr-4 font-semibold">Plan</th>
                            <th class="py-3 pr-4 font-semibold">Inicio</th>
                            <th class="py-3 pr-4 font-semibold">Vence</th>
                            <th class="py-3 pr-4 font-semibold">Días</th>
                            <th class="py-3 pr-4 font-semibold">Usuarios</th>
                            <th class="py-3 pr-6 font-semibold">Estado</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-olive-100">
                        <?php $__currentLoopData = $opticas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-cream/70 transition">
                                <td class="py-3 pl-6 pr-4 whitespace-nowrap">
                                    <a href="<?php echo e(route('superadmin.empresas.show', $o->nit)); ?>" class="font-medium hover:text-olive-700"><?php echo e($o->empresa); ?></a>
                                    <p class="text-[11px] text-muted">NIT <?php echo e($o->nit); ?> · <?php echo e($o->email); ?></p>
                                </td>
                                <td class="py-3 pr-4 whitespace-nowrap"><?php echo e($o->plan ?? 'Sin plan'); ?></td>
                                <td class="py-3 pr-4 whitespace-nowrap text-ink/70 tabular-nums"><?php echo e($o->fecha_inicio ? \Illuminate\Support\Carbon::parse($o->fecha_inicio)->format('d/m/Y') : '—'); ?></td>
                                <td class="py-3 pr-4 whitespace-nowrap text-ink/70 tabular-nums"><?php echo e($o->fecha_fin ? \Illuminate\Support\Carbon::parse($o->fecha_fin)->format('d/m/Y') : '—'); ?></td>
                                <td class="py-3 pr-4"><?php echo $__env->make('partials.estado-licencia', ['dias' => $o->dias_restantes !== null ? (int) $o->dias_restantes : null, 'solo' => 'dias'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                                <td class="py-3 pr-4 tabular-nums text-ink/80"><?php echo e($o->usuarios_registrados); ?></td>
                                <td class="py-3 pr-6"><?php echo $__env->make('partials.estado-licencia', ['estado' => $o->estado_licencia, 'solo' => 'estado'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    
    <div id="actividad" class="bg-white rounded-2xl border border-olive-100 shadow-card overflow-hidden scroll-mt-24">
        <div class="px-5 sm:px-6 pt-5 pb-4 border-b border-olive-100 flex items-center gap-3 flex-wrap">
            <div class="w-9 h-9 rounded-xl bg-olive-100 text-olive-700 flex items-center justify-center">
                <?php echo $__env->make('partials.icon', ['name' => 'file-text', 'class' => 'w-4.5 h-4.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="flex-1 min-w-[12rem]">
                <h3 class="font-serif text-lg leading-tight">Registro de actividad</h3>
                <p class="text-xs text-muted">Lo que ha pasado en todas las ópticas</p>
            </div>
            <form method="GET" action="<?php echo e(route('superadmin.reportes.index')); ?>#actividad" class="flex flex-wrap items-center gap-2">
                <?php $__currentLoopData = $conservar(['nit', 'accion']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <select name="nit" class="<?php echo e($campo); ?>" onchange="this.form.submit()">
                    <option value="">Todas las ópticas</option>
                    <?php $__currentLoopData = $listaOpticas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($e->nit); ?>" <?php if($nitActividad === $e->nit): echo 'selected'; endif; ?>><?php echo e($e->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="accion" class="<?php echo e($campo); ?>" onchange="this.form.submit()">
                    <option value="">Todas las acciones</option>
                    <?php $__currentLoopData = $acciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($a); ?>" <?php if($accion === $a): echo 'selected'; endif; ?>><?php echo e(ucfirst($a)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($nitActividad !== '' || $accion !== ''): ?>
                    <a href="<?php echo e(route('superadmin.reportes.index', $conservar(['nit', 'accion'])->all())); ?>#actividad" class="text-xs font-semibold text-olive-600 hover:text-olive-800">Quitar filtros</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-cream text-left text-[11px] uppercase tracking-wider text-muted">
                        <th class="py-3 pl-6 pr-4 font-semibold">Fecha</th>
                        <th class="py-3 pr-4 font-semibold">Óptica</th>
                        <th class="py-3 pr-4 font-semibold">Acción</th>
                        <th class="py-3 pr-4 font-semibold">Detalle</th>
                        <th class="py-3 pr-6 font-semibold">Usuario</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-olive-100">
                    <?php $__empty_1 = true; $__currentLoopData = $actividad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-cream/70 transition">
                            <td class="py-3 pl-6 pr-4 whitespace-nowrap text-ink/70 tabular-nums"><?php echo e($a->fecha?->format('d/m/Y H:i')); ?></td>
                            <td class="py-3 pr-4 whitespace-nowrap"><?php echo e($a->empresa->nombre ?? 'VisiOptica'); ?></td>
                            <td class="py-3 pr-4 whitespace-nowrap">
                                <span class="text-[11px] font-semibold uppercase tracking-wide text-olive-700 bg-olive-50 rounded px-2 py-0.5"><?php echo e($a->accion); ?></span>
                            </td>
                            <td class="py-3 pr-4 text-ink/80"><?php echo e($a->descripcion); ?></td>
                            <td class="py-3 pr-6 whitespace-nowrap text-ink/70"><?php echo e($a->usuario->nombres ?? 'Sistema'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="px-6 py-10 text-center text-muted">Sin actividad registrada.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($actividad->hasPages()): ?>
            <div class="px-6 py-4 border-t border-olive-100 flex items-center justify-between text-sm">
                <span class="text-muted">Página <?php echo e($actividad->currentPage()); ?> de <?php echo e($actividad->lastPage()); ?></span>
                <div class="flex gap-2">
                    <?php if($actividad->previousPageUrl()): ?>
                        <a href="<?php echo e($actividad->previousPageUrl()); ?>" class="px-3 py-1.5 rounded-lg border border-olive-100 hover:bg-olive-50">Anterior</a>
                    <?php endif; ?>
                    <?php if($actividad->nextPageUrl()): ?>
                        <a href="<?php echo e($actividad->nextPageUrl()); ?>" class="px-3 py-1.5 rounded-lg border border-olive-100 hover:bg-olive-50">Siguiente</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const el = document.getElementById('graficaIngresos');
        if (!el || typeof Chart === 'undefined') return;

        new Chart(el, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($grafica['labels'], 15, 512) ?>,
                datasets: [{
                    data: <?php echo json_encode($grafica['data'], 15, 512) ?>,
                    backgroundColor: '#93762E',
                    borderRadius: 8,
                    maxBarThickness: 48,
                }],
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: (c) => '$' + Number(c.raw).toLocaleString('es-CO') } },
                },
                scales: {
                    x: { grid: { display: false } },
                    y: { beginAtZero: true, ticks: { callback: (v) => '$' + Number(v).toLocaleString('es-CO') } },
                },
            },
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.superadmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\visilux_3\resources\views/superadmin/reportes/index.blade.php ENDPATH**/ ?>